CMPT 372 asn2

Hin Lui 301571436


Instructions:
    
    1. Open terminal

    2. Navigate to the current folder (after decompress)

    3. Run `docker pull luihin903/recipeapp-server:first`

    4. Run `docker pull luihin903/postgres:first`

    5. Run `docker-compose up`

    6. Open web browser and navigate to `localhost:3000`
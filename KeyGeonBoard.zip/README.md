# v0.5.2 @18/3/2024

    1. Change background in Dead scene

    2. Change Endings text